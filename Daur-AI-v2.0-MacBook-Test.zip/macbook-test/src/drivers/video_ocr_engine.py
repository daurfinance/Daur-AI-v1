"""
Видео OCR движок - заглушка
"""

class VideoOCREngine:
    def __init__(self):
        pass
    
    def extract_text_from_frame(self, frame):
        return []
    
    def cleanup(self):
        pass
