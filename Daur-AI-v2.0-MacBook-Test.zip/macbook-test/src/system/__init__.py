"""
Модуль системного управления Daur-AI
Продвинутое управление операционной системой
"""

from .advanced_controller import AdvancedSystemController

__all__ = ['AdvancedSystemController']
